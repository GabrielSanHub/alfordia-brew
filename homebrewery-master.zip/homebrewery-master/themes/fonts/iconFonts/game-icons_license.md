# Game Icons License

The font used in gameIcons.woff / gameIcons.less / gameIcons.js, and usable in the Homebrewery as "gi" icons, are a subset of the Game-Icons.net library of icons.

## The license

Game-Icons has this to say about their license:

> Game-icons.net is an online repository providing heaps of cool game related graphics.
> 
> They are provided provided under the terms of the Creative Commons 3.0 BY license.
> 
> It means that you can use them freely as long as you credit the original author in your creation(see below). A mention like "Icons made by {author;}. Available on https://game-icons.net" is fine.