# License

DiceFont is open source. You can use it for commercial projects, personal
projects or open source projects.

## Font License

Applies to all desktop and webfont files: [License: SIL OFL 1.1](http://scripts.sil.org/OFL)

## Code License

Applies to all CSS and LESS files: [License: MIT License](http://opensource.org/licenses/mit-license.html)

## Documentation License

Applies to all other files [CC BY 3.0](http://creativecommons.org/licenses/by/3.0/)

Copyright [Franco Ponticelli](https://github.com/fponticelli).
